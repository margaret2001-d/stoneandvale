export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  description: string;
  sizes: string[];
  featured: boolean;
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Overcoat Charcoal',
    price: 485,
    category: 'Outerwear',
    description: 'Premium wool overcoat in charcoal grey. Tailored fit with minimalist silhouette.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: true,
  },
  {
    id: '2',
    name: 'Structured Blazer',
    price: 395,
    category: 'Blazers',
    description: 'Single-breasted blazer with structured shoulders and clean lines.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: true,
  },
  {
    id: '3',
    name: 'Merino Roll Neck',
    price: 145,
    category: 'Knitwear',
    description: 'Fine merino wool roll neck sweater in black.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: true,
  },
  {
    id: '4',
    name: 'Tapered Trousers',
    price: 195,
    category: 'Trousers',
    description: 'Tapered cotton trousers with a clean, modern silhouette.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: false,
  },
  {
    id: '5',
    name: 'Crew Neck Tee',
    price: 75,
    category: 'Tops',
    description: 'Premium heavyweight cotton crew neck in white.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: true,
  },
  {
    id: '6',
    name: 'Bomber Jacket',
    price: 320,
    category: 'Outerwear',
    description: 'Minimalist bomber in black matte nylon with clean detailing.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: false,
  },
  {
    id: '7',
    name: 'Relaxed Shirt',
    price: 165,
    category: 'Shirts',
    description: 'Relaxed fit button-up shirt in crisp white cotton.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: false,
  },
  {
    id: '8',
    name: 'Tailored Trench',
    price: 550,
    category: 'Outerwear',
    description: 'Modern reinterpretation of the classic trench coat in stone.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: true,
  },
  {
    id: '9',
    name: 'Cashmere Beanie',
    price: 95,
    category: 'Accessories',
    description: 'Fine cashmere knit beanie in black.',
    sizes: ['One Size'],
    featured: false,
  },
  {
    id: '10',
    name: 'Leather Belt',
    price: 125,
    category: 'Accessories',
    description: 'Italian leather belt with minimalist matte buckle.',
    sizes: ['S', 'M', 'L'],
    featured: false,
  },
  {
    id: '11',
    name: 'Cashmere Scarf',
    price: 180,
    category: 'Accessories',
    description: 'Oversized cashmere scarf in heather grey.',
    sizes: ['One Size'],
    featured: false,
  },
  {
    id: '12',
    name: 'Slim Jeans',
    price: 175,
    category: 'Trousers',
    description: 'Slim fit jeans in dark wash with minimal detailing.',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: false,
  },
];

export const categories = ['All', 'Outerwear', 'Blazers', 'Shirts', 'Knitwear', 'Trousers', 'Tops', 'Accessories'];
