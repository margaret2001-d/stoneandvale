import { useState } from 'react';

interface PlaceholderImageProps {
  name: string;
  className?: string;
}

export function PlaceholderImage({ name, className = '' }: PlaceholderImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className={`relative overflow-hidden bg-stone-200 ${className}`}>
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-stone-300 border-t-stone-800 rounded-full animate-spin" />
        </div>
      )}
      <img
        src={`https://placehold.co/600x800/1c1917/d6d3d1?text=${encodeURIComponent(name)}`}
        alt={name}
        className={`w-full h-full object-cover transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
        onLoad={() => setIsLoaded(true)}
        loading="lazy"
      />
    </div>
  );
}
