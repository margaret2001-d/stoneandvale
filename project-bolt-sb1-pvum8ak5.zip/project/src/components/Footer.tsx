import { Link } from 'react-router-dom';
import { Instagram } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-stone-950 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <h3 className="font-display text-2xl font-semibold mb-4">Stone & Vale</h3>
            <p className="text-stone-400 text-sm leading-relaxed max-w-xs">
              Premium menswear designed for the modern man. Minimalist silhouettes, 
              exceptional materials, timeless style.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-medium tracking-extra-wide uppercase mb-6">Explore</h4>
            <ul className="space-y-3">
              {[
                { path: '/', label: 'Home' },
                { path: '/shop', label: 'Shop' },
                { path: '/about', label: 'About' },
                { path: '/contact', label: 'Contact' },
              ].map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-stone-400 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-medium tracking-extra-wide uppercase mb-6">Follow</h4>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 text-stone-400 hover:text-white transition-colors text-sm group"
            >
              <Instagram size={20} className="transition-transform group-hover:scale-110" />
              <span>@stoneandvale</span>
            </a>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-stone-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-stone-500 text-xs tracking-wide">
            © {new Date().getFullYear()} Stone & Vale. All rights reserved.
          </p>
          <p className="text-stone-500 text-xs tracking-wide">
            Designed with precision.
          </p>
        </div>
      </div>
    </footer>
  );
}
