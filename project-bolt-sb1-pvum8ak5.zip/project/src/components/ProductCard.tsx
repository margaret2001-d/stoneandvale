import { useState } from 'react';
import { Product } from '../data/products';
import { PlaceholderImage } from './PlaceholderImage';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="group cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative overflow-hidden bg-stone-100 aspect-[3/4] mb-4">
        <PlaceholderImage
          name={product.name}
          className="w-full h-full transition-transform duration-700 ease-out group-hover:scale-105"
        />
        {isHovered && (
          <div className="absolute inset-0 bg-black/5 transition-opacity duration-300" />
        )}
        <div className="absolute bottom-4 left-4 right-4 flex gap-2 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
          {product.sizes.map((size) => (
            <span
              key={size}
              className="bg-white text-stone-900 text-xs font-medium px-3 py-1.5 shadow-sm"
            >
              {size}
            </span>
          ))}
        </div>
      </div>
      <div className="space-y-1">
        <p className="text-xs text-stone-500 tracking-wide uppercase">{product.category}</p>
        <h3 className="text-sm font-medium text-stone-900">{product.name}</h3>
        <p className="text-sm font-medium text-stone-700">${product.price}</p>
      </div>
    </div>
  );
}
