import { useState } from 'react';
import { Mail, MapPin, Phone, Instagram, Send } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 lg:py-24">
        <div className="max-w-3xl mx-auto text-center mb-20">
          <p className="text-sm text-stone-500 tracking-extra-wide uppercase mb-4">Get in Touch</p>
          <h1 className="font-display text-4xl md:text-5xl font-semibold text-stone-900 mb-8">
            Contact
          </h1>
          <p className="text-lg text-stone-600 leading-relaxed">
            We would love to hear from you. Whether you have a question about our collections,
            sizing, or simply want to say hello.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h3 className="text-sm font-medium tracking-extra-wide uppercase text-stone-900 mb-6">
                Contact Information
              </h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Mail size={20} className="text-stone-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-stone-900">Email</p>
                    <a href="mailto:hello@stoneandvale.com" className="text-sm text-stone-600 hover:text-stone-900 transition-colors">
                      hello@stoneandvale.com
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Phone size={20} className="text-stone-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-stone-900">Phone</p>
                    <a href="tel:+1-555-0199" className="text-sm text-stone-600 hover:text-stone-900 transition-colors">
                      +1 (555) 019-9123
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <MapPin size={20} className="text-stone-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-stone-900">Studio</p>
                    <p className="text-sm text-stone-600">
                      128 Mercer Street<br />
                      New York, NY 10012
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium tracking-extra-wide uppercase text-stone-900 mb-6">
                Follow Us
              </h3>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 text-stone-600 hover:text-stone-900 transition-colors group"
              >
                <Instagram size={20} className="transition-transform group-hover:scale-110" />
                <span className="text-sm">@stoneandvale</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-stone-900 mb-2">
                    Name
                  </label>
                  <input
                    id="name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-stone-900 transition-colors bg-white"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-stone-900 mb-2">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-stone-900 transition-colors bg-white"
                    placeholder="you@example.com"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-stone-900 mb-2">
                  Subject
                </label>
                <input
                  id="subject"
                  type="text"
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-4 py-3 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-stone-900 transition-colors bg-white"
                  placeholder="How can we help?"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-stone-900 mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  required
                  rows={6}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-stone-900 transition-colors bg-white resize-none"
                  placeholder="Tell us more..."
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-3 bg-stone-900 text-white px-8 py-4 text-sm font-medium tracking-extra-wide uppercase hover:bg-stone-800 transition-colors"
              >
                {submitted ? 'Message Sent' : 'Send Message'}
                <Send size={16} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
