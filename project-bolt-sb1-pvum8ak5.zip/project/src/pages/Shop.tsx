import { useState } from 'react';
import { products, categories } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { SlidersHorizontal } from 'lucide-react';

export function Shop() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const filtered = activeCategory === 'All'
    ? products
    : products.filter((p) => p.category === activeCategory);

  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 lg:py-24">
        <div className="mb-12">
          <p className="text-sm text-stone-500 tracking-extra-wide uppercase mb-3">Collection</p>
          <h1 className="font-display text-4xl md:text-5xl font-semibold text-stone-900">Shop</h1>
        </div>

        <div className="flex flex-col md:flex-row md:items-center gap-6 mb-12">
          <button
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className="md:hidden inline-flex items-center gap-2 text-sm font-medium text-stone-900 border border-stone-300 px-4 py-2"
          >
            <SlidersHorizontal size={16} />
            Filters
          </button>

          <div className={`md:flex flex-wrap gap-2 ${isFilterOpen ? 'flex' : 'hidden'}`}>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 text-sm font-medium transition-all duration-300 ${
                  activeCategory === cat
                    ? 'bg-stone-900 text-white'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <p className="text-sm text-stone-500 ml-auto">
            {filtered.length} {filtered.length === 1 ? 'item' : 'items'}
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
