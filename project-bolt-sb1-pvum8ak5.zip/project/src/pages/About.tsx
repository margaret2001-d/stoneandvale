import { PlaceholderImage } from '../components/PlaceholderImage';

export function About() {
  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 lg:py-24">
        <div className="max-w-3xl mx-auto text-center mb-20">
          <p className="text-sm text-stone-500 tracking-extra-wide uppercase mb-4">Our Story</p>
          <h1 className="font-display text-4xl md:text-5xl font-semibold text-stone-900 mb-8">
            About Stone & Vale
          </h1>
          <p className="text-lg text-stone-600 leading-relaxed">
            Founded on the belief that less is more, Stone & Vale creates menswear for the
            modern individual who values quality over quantity. Our designs are rooted in
            timeless principles and crafted with meticulous attention to detail.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-24">
          <div className="relative aspect-[4/3] overflow-hidden">
            <PlaceholderImage name="Our Studio" className="w-full h-full" />
          </div>
          <div>
            <h2 className="font-display text-2xl md:text-3xl font-semibold text-stone-900 mb-6">
              The Philosophy
            </h2>
            <p className="text-stone-600 leading-relaxed mb-6">
              We believe in the power of restraint. Every seam, every fabric, every silhouette
              is considered and deliberate. Our collections are built around a cohesive palette
              of neutrals — black, white, stone, and charcoal — that allow the quality of
              the materials and the precision of the cut to speak for themselves.
            </p>
            <p className="text-stone-600 leading-relaxed">
              This is clothing that does not shout. It whispers. It endures. It becomes part of
              who you are.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-24">
          <div className="order-2 lg:order-1">
            <h2 className="font-display text-2xl md:text-3xl font-semibold text-stone-900 mb-6">
              Craftsmanship
            </h2>
            <p className="text-stone-600 leading-relaxed mb-6">
              We partner with skilled artisans and ethical manufacturers who share our
              commitment to excellence. Every garment is constructed using premium materials
              sourced from trusted suppliers across Europe and Asia.
            </p>
            <p className="text-stone-600 leading-relaxed">
              From our Italian wool overcoats to our Japanese cotton tees, each piece is
              designed to age gracefully and wear beautifully over time.
            </p>
          </div>
          <div className="order-1 lg:order-2 relative aspect-[4/3] overflow-hidden">
            <PlaceholderImage name="Craftsmanship" className="w-full h-full" />
          </div>
        </div>

        <div className="bg-stone-50 py-20 px-8 lg:px-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div>
              <p className="font-display text-4xl font-semibold text-stone-900 mb-3">2019</p>
              <p className="text-sm text-stone-500 tracking-wide uppercase">Founded</p>
            </div>
            <div>
              <p className="font-display text-4xl font-semibold text-stone-900 mb-3">12</p>
              <p className="text-sm text-stone-500 tracking-wide uppercase">Countries</p>
            </div>
            <div>
              <p className="font-display text-4xl font-semibold text-stone-900 mb-3">100%</p>
              <p className="text-sm text-stone-500 tracking-wide uppercase">Ethical Sourcing</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
