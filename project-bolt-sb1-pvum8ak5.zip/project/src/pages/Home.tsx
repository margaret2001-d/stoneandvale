import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { products } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { PlaceholderImage } from '../components/PlaceholderImage';

function useIntersectionAnimation() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add('animate-in');
          observer.unobserve(el);
        }
      },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return ref;
}

function FadeInSection({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useIntersectionAnimation();
  return (
    <div
      ref={ref}
      className={`opacity-0 translate-y-8 transition-all duration-1000 ease-out ${className}`}
      style={{ transitionDelay: '0.1s' }}
      onTransitionEnd={(e) => {
        if (e.currentTarget.classList.contains('animate-in')) {
          e.currentTarget.style.opacity = '1';
          e.currentTarget.style.transform = 'translateY(0)';
        }
      }}
    >
      {children}
    </div>
  );
}

export function Home() {
  const featured = products.filter((p) => p.featured);

  return (
    <div>
      {/* Hero */}
      <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-stone-900">
          <img
            src="https://placehold.co/1920x1080/1c1917/57534e?text=Stone+%26+Vale"
            alt="Stone & Vale"
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        <div className="relative z-10 text-center px-6">
          <p className="text-white/60 text-sm tracking-extra-wide uppercase mb-6">
            Premium Menswear
          </p>
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-semibold text-white mb-8 tracking-tight">
            Stone & Vale
          </h1>
          <p className="text-white/70 text-lg md:text-xl max-w-lg mx-auto mb-10 font-light">
            Minimalist design. Exceptional quality. Timeless style.
          </p>
          <Link
            to="/shop"
            className="inline-flex items-center gap-3 bg-white text-stone-900 px-8 py-4 text-sm font-medium tracking-extra-wide uppercase hover:bg-stone-100 transition-colors duration-300"
          >
            Shop Collection
            <ArrowRight size={16} />
          </Link>
        </div>
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
          <div className="w-px h-12 bg-white/30 animate-pulse" />
        </div>
      </section>

      {/* Featured Collection */}
      <section className="py-24 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <FadeInSection>
            <div className="flex items-end justify-between mb-12">
              <div>
                <p className="text-sm text-stone-500 tracking-extra-wide uppercase mb-3">Curated</p>
                <h2 className="font-display text-3xl md:text-4xl font-semibold text-stone-900">Featured Collection</h2>
              </div>
              <Link
                to="/shop"
                className="hidden md:inline-flex items-center gap-2 text-sm font-medium text-stone-900 hover:text-stone-600 transition-colors"
              >
                View All
                <ArrowRight size={16} />
              </Link>
            </div>
          </FadeInSection>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="mt-10 text-center md:hidden">
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 text-sm font-medium text-stone-900 hover:text-stone-600 transition-colors"
            >
              View All Products
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Editorial Section */}
      <section className="py-24 lg:py-32 bg-stone-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <FadeInSection>
              <div className="relative aspect-[4/5] overflow-hidden">
                <PlaceholderImage name="The Edit" className="w-full h-full" />
              </div>
            </FadeInSection>
            <FadeInSection>
              <div className="lg:pl-8">
                <p className="text-sm text-stone-500 tracking-extra-wide uppercase mb-4">The Edit</p>
                <h2 className="font-display text-3xl md:text-4xl font-semibold text-stone-900 mb-6">
                  Designed for the Modern Man
                </h2>
                <p className="text-stone-600 leading-relaxed mb-8">
                  Every piece in the Stone & Vale collection is crafted with an uncompromising
                  commitment to quality and a minimalist design philosophy. We believe that
                  true style lies in simplicity — clean lines, premium materials, and
                  silhouettes that transcend seasons.
                </p>
                <p className="text-stone-600 leading-relaxed mb-10">
                  From our signature outerwear to our carefully curated accessories, each
                  item is designed to be a staple in your wardrobe for years to come.
                </p>
                <Link
                  to="/about"
                  className="inline-flex items-center gap-2 text-sm font-medium text-stone-900 hover:text-stone-600 transition-colors border-b border-stone-900 pb-1"
                >
                  Our Story
                  <ArrowRight size={16} />
                </Link>
              </div>
            </FadeInSection>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-24 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <FadeInSection>
            <div className="text-center mb-16">
              <p className="text-sm text-stone-500 tracking-extra-wide uppercase mb-3">Browse</p>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-stone-900">Shop by Category</h2>
            </div>
          </FadeInSection>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: 'Outerwear', count: 3 },
              { name: 'Blazers', count: 1 },
              { name: 'Knitwear', count: 1 },
              { name: 'Accessories', count: 3 },
            ].map((cat) => (
              <FadeInSection key={cat.name}>
                <Link to="/shop" className="group relative block overflow-hidden aspect-[3/4] bg-stone-100">
                  <PlaceholderImage name={cat.name} className="w-full h-full transition-transform duration-700 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors duration-300" />
                  <div className="absolute bottom-6 left-6">
                    <h3 className="text-white text-lg font-medium">{cat.name}</h3>
                    <p className="text-white/70 text-sm">{cat.count} items</p>
                  </div>
                </Link>
              </FadeInSection>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
